// ===========================================
// Part 1 & 2: Event Handling & Interactive Elements
// ===========================================

// -------------------------------------------
// Counter Game
// -------------------------------------------
const decrementBtn = document.getElementById('decrement-btn');
const incrementBtn = document.getElementById('increment-btn');
const counterValueSpan = document.getElementById('counter-value');
const counterMessage = document.getElementById('counter-message');

let counter = 0;

// Function to update the counter display and a message
function updateCounter(change) {
    counter += change;
    counterValueSpan.textContent = counter;

    if (counter > 0) {
        counterMessage.textContent = 'The counter is positive! 🎉';
    } else if (counter < 0) {
        counterMessage.textContent = 'The counter is negative. 😞';
    } else {
        counterMessage.textContent = 'The counter is zero.';
    }
}

// Event listener for the decrement button
decrementBtn.addEventListener('click', () => {
    updateCounter(-1);
});

// Event listener for the increment button
incrementBtn.addEventListener('click', () => {
    updateCounter(1);
});


// -------------------------------------------
// Collapsible FAQ Section
// -------------------------------------------
const faqQuestions = document.querySelectorAll('.faq-question');

// Loop through each FAQ question button
faqQuestions.forEach(question => {
    // Add a click event listener to each button
    question.addEventListener('click', () => {
        // Toggle the 'active' class on the clicked button
        question.classList.toggle('active');

        // Select the next sibling element, which is the answer
        const answer = question.nextElementSibling;
        
        // Toggle the 'show' class on the answer to reveal or hide it
        answer.classList.toggle('show');
    });
});


// ===========================================
// Part 3: Form Validation
// ===========================================

const contactForm = document.getElementById('contact-form');
const nameInput = document.getElementById('name');
const emailInput = document.getElementById('email');
const passwordInput = document.getElementById('password');
const nameError = document.getElementById('name-error');
const emailError = document.getElementById('email-error');
const passwordError = document.getElementById('password-error');
const formSuccessMessage = document.getElementById('form-success-message');

// Function to validate the name field
function validateName() {
    // Check if the name field is empty
    if (nameInput.value.trim() === '') {
        nameError.textContent = 'Name is required.';
        return false;
    } else {
        nameError.textContent = '';
        return true;
    }
}

// Function to validate the email field using a regular expression
function validateEmail() {
    // Regular expression for a basic email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    
    // Check if the email field is empty or doesn't match the regex
    if (emailInput.value.trim() === '') {
        emailError.textContent = 'Email is required.';
        return false;
    } else if (!emailRegex.test(emailInput.value)) {
        emailError.textContent = 'Please enter a valid email address.';
        return false;
    } else {
        emailError.textContent = '';
        return true;
    }
}

// Function to validate the password field
function validatePassword() {
    // A simple password validation rule: at least 8 characters
    const password = passwordInput.value.trim();
    if (password === '') {
        passwordError.textContent = 'Password is required.';
        return false;
    } else if (password.length < 8) {
        passwordError.textContent = 'Password must be at least 8 characters long.';
        return false;
    } else {
        passwordError.textContent = '';
        return true;
    }
}

// Add event listeners for real-time validation feedback as the user types
nameInput.addEventListener('input', validateName);
emailInput.addEventListener('input', validateEmail);
passwordInput.addEventListener('input', validatePassword);


// Add a 'submit' event listener to the form
contactForm.addEventListener('submit', (e) => {
    // Prevent the default form submission behavior (which would reload the page)
    e.preventDefault();

    // Run all validation functions and check if they all return true
    const isNameValid = validateName();
    const isEmailValid = validateEmail();
    const isPasswordValid = validatePassword();
    
    // If all fields are valid, show a success message
    if (isNameValid && isEmailValid && isPasswordValid) {
        formSuccessMessage.textContent = 'Form submitted successfully! ✅';
        // Clear the form fields after successful submission
        contactForm.reset();
        
        // You would typically send the form data to a server here using fetch()
        // console.log('Form data:', {
        //     name: nameInput.value,
        //     email: emailInput.value,
        //     password: passwordInput.value
        // });
    } else {
        // If there are validation errors, clear any previous success message
        formSuccessMessage.textContent = '';
    }
});